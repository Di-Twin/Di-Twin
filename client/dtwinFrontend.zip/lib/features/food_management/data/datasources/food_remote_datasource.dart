import 'dart:math';
import 'package:flutter/material.dart';
import '../models/food_item_model.dart';
import '../models/nutrition_data_model.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/errors/exceptions.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

abstract class FoodRemoteDataSource {
  Future<Map<String, List<FoodItemModel>>> getDailyFoodData(String date);
  Future<String> getFoodScore();
  Future<String> getDailyFoodScore(String accessToken, String date);
  Future<List<FoodItemModel>> getPopularFoods();
  Future<NutritionDataModel> getNutritionData(DateTime date);
  Future<void> addFoodItem(FoodItemModel foodItem);
  Future<void> updateFoodItem(FoodItemModel foodItem);
  Future<void> deleteFoodItem(String id);
  Future<bool> logFoodItems(String accessToken, String date, List<Map<String, dynamic>> foodItems);
}

class FoodRemoteDataSourceImpl implements FoodRemoteDataSource {
  final ApiClient apiClient;
  final String cacheKeyPrefix = 'daily_food_score_';
  
  FoodRemoteDataSourceImpl({required this.apiClient});

  @override
  Future<Map<String, List<FoodItemModel>>> getDailyFoodData(String date) async {
    try {
      final response = await apiClient.get('/food/daily/$date');
      
      Map<String, List<FoodItemModel>> result = {};
      
      response.forEach((mealType, foods) {
        result[mealType] = (foods as List)
            .map((food) => FoodItemModel.fromJson(food))
            .toList();
      });
      
      return result;
    } catch (e) {
      // For demo purposes, return mock data if API fails
      throw ServerException(
        message: 'Error fetching daily food data: ${e.toString()}',
        statusCode: 500,
      );
    }
  }

  @override
  Future<String> getFoodScore() async {
    try {
      final response = await apiClient.get('/food/score');
      return response['score'].toString();
    } catch (e) {
      // For demo purposes, return mock score if API fails
      throw ServerException(
        message: 'Error fetching food score: ${e.toString()}',
        statusCode: 500,
      );
    }
  }
  
  @override
  Future<String> getDailyFoodScore(String accessToken, String date) async {
    try {
      // Generate cache key based on date
      final cacheKey = '$cacheKeyPrefix$date';
      
      // First check if we have a cached value
      final prefs = await SharedPreferences.getInstance();
      final cachedScore = prefs.getString(cacheKey);
      
      // If we have a cached value and it's less than 1 hour old, return it
      final lastUpdated = prefs.getInt('${cacheKey}_timestamp');
      final now = DateTime.now().millisecondsSinceEpoch;
      
      if (cachedScore != null && lastUpdated != null) {
        final diff = now - lastUpdated;
        if (diff < 3600000) { // Less than 1 hour
          return cachedScore;
        }
      }
      
      // Otherwise, fetch from API using the correct endpoint format
      final response = await apiClient.get(
        '/food/score/daily/$date',
      );
      
      print('Daily food score response: $response');
      
      // Extract score from response
      final score = response['score']?.toString() ?? 
                   response['data']?['score']?.toString() ?? 
                   '0';
      
      // Cache the result
      await prefs.setString(cacheKey, score);
      await prefs.setInt('${cacheKey}_timestamp', now);
      
      return score;
    } catch (e) {
      print('Error getting daily food score: $e');
      
      // Try to get from cache even if it's old
      final cacheKey = '$cacheKeyPrefix$date';
      final prefs = await SharedPreferences.getInstance();
      final cachedScore = prefs.getString(cacheKey);
      
      if (cachedScore != null) {
        return cachedScore;
      }
      
      // If all else fails, throw exception
      throw ServerException(
        message: 'Error fetching daily food score: ${e.toString()}',
        statusCode: 500,
      );
    }
  }

  @override
  Future<List<FoodItemModel>> getPopularFoods() async {
    try {
      final response = await apiClient.get('/food/popular');
      return (response as List)
          .map((food) => FoodItemModel.fromJson(food))
          .toList();
    } catch (e) {
      throw ServerException(
        message: 'Error fetching popular foods: ${e.toString()}',
        statusCode: 500,
      );
    }
  }

  @override
  Future<NutritionDataModel> getNutritionData(DateTime date) async {
    try {
      final dateStr = date.toIso8601String().split('T')[0]; // Get YYYY-MM-DD format
      final response = await apiClient.get('/food/nutrition/$dateStr');
      return NutritionDataModel.fromJson(response);
    } catch (e) {
      throw ServerException(
        message: 'Error fetching nutrition data: ${e.toString()}',
        statusCode: 500,
      );
    }
  }

  @override
  Future<void> addFoodItem(FoodItemModel foodItem) async {
    try {
      await apiClient.post('/food/add', body: foodItem.toJson());
    } catch (e) {
      throw ServerException(
        message: 'Error adding food item: ${e.toString()}',
        statusCode: 500,
      );
    }
  }

  @override
  Future<void> updateFoodItem(FoodItemModel foodItem) async {
    try {
      await apiClient.put('/food/update/${foodItem.id}', body: foodItem.toJson());
    } catch (e) {
      throw ServerException(
        message: 'Error updating food item: ${e.toString()}',
        statusCode: 500,
      );
    }
  }

  @override
  Future<void> deleteFoodItem(String id) async {
    try {
      await apiClient.delete('/food/delete/$id');
    } catch (e) {
      throw ServerException(
        message: 'Error deleting food item: ${e.toString()}',
        statusCode: 500,
      );
    }
  }
  
  @override
  Future<bool> logFoodItems(String accessToken, String date, List<Map<String, dynamic>> foodItems) async {
    try {
      final requestBody = {
        "date": date,
        "foodItems": foodItems
      };
      
      print('Logging food items: $requestBody');
      
      final response = await apiClient.post(
        '/api/food/',
        body: requestBody,
      );
      
      print('Log food response: $response');
      
      // Check if the response indicates success
      final success = response['success'] ?? false;
      
      return success;
    } catch (e) {
      print('Error logging food items: $e');
      throw ServerException(
        message: 'Error logging food items: ${e.toString()}',
        statusCode: 500,
      );
    }
  }
}
