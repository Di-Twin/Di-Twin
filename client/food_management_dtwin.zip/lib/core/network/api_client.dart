import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  final String baseUrl;
  final http.Client httpClient;
  
  ApiClient({
    required this.baseUrl,
    required this.httpClient,
  });

  // Helper method to get the auth token
  Future<String?> _getAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('access_token');
  }

  // Helper method to create headers with auth token
  Future<Map<String, String>> _getHeaders({bool requiresAuth = true}) async {
    final headers = {
      'Content-Type': 'application/json',
    };
    
    if (requiresAuth) {
      final token = await _getAuthToken();
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      } else {
        print('Warning: No auth token available for API request');
      }
    }
    
    return headers;
  }

  Future<dynamic> get(String endpoint, {bool requiresAuth = true}) async {
    try {
      final uri = Uri.parse('$baseUrl$endpoint');
      print('🌐 GET Request: $uri');
      
      final headers = await _getHeaders(requiresAuth: requiresAuth);
      final response = await httpClient.get(
        uri,
        headers: headers,
      ).timeout(const Duration(seconds: 60));

      print('📥 Response Status: ${response.statusCode}');
      
      if (response.statusCode >= 200 && response.statusCode < 300) {
        final responseBody = response.body;
        print('📦 Response Size: ${responseBody.length} bytes');
        return json.decode(responseBody);
      } else {
        print('❌ Error Response: ${response.body}');
        throw ApiException('Failed to load data: ${response.statusCode}', response.statusCode);
      }
    } on SocketException {
      print('🔌 Network Error: No internet connection');
      throw ApiException('No internet connection', 0);
    } on TimeoutException {
      print('⏱️ Request Timeout');
      throw ApiException('Request timeout', 408);
    } on FormatException {
      print('🔄 Invalid Response Format');
      throw ApiException('Invalid response format', 0);
    } catch (e) {
      print('💥 Unexpected Error: $e');
      throw ApiException('Unexpected error: $e', 0);
    }
  }

  Future<dynamic> post(String endpoint, {required Map<String, dynamic> body, bool requiresAuth = true}) async {
    try {
      final uri = Uri.parse('$baseUrl$endpoint');
      print('🌐 POST Request: $uri');
      print('📤 Request Body: ${json.encode(body)}');
      
      final headers = await _getHeaders(requiresAuth: requiresAuth);
      final response = await httpClient.post(
        uri,
        headers: headers,
        body: json.encode(body),
      ).timeout(const Duration(seconds: 60));

      print('📥 Response Status: ${response.statusCode}');
      
      if (response.statusCode >= 200 && response.statusCode < 300) {
        final responseBody = response.body;
        print('📦 Response Size: ${responseBody.length} bytes');
        return json.decode(responseBody);
      } else {
        print('❌ Error Response: ${response.body}');
        throw ApiException('Failed to post data: ${response.statusCode}', response.statusCode);
      }
    } on SocketException {
      print('🔌 Network Error: No internet connection');
      throw ApiException('No internet connection', 0);
    } on TimeoutException {
      print('⏱️ Request Timeout');
      throw ApiException('Request timeout', 408);
    } on FormatException {
      print('🔄 Invalid Response Format');
      throw ApiException('Invalid response format', 0);
    } catch (e) {
      print('💥 Unexpected Error: $e');
      throw ApiException('Unexpected error: $e', 0);
    }
  }

  Future<dynamic> put(String endpoint, {required Map<String, dynamic> body, bool requiresAuth = true}) async {
    try {
      final uri = Uri.parse('$baseUrl$endpoint');
      print('🌐 PUT Request: $uri');
      print('📤 Request Body: ${json.encode(body)}');
      
      final headers = await _getHeaders(requiresAuth: requiresAuth);
      final response = await httpClient.put(
        uri,
        headers: headers,
        body: json.encode(body),
      ).timeout(const Duration(seconds: 60));

      print('📥 Response Status: ${response.statusCode}');
      
      if (response.statusCode >= 200 && response.statusCode < 300) {
        final responseBody = response.body;
        print('📦 Response Size: ${responseBody.length} bytes');
        return json.decode(responseBody);
      } else {
        print('❌ Error Response: ${response.body}');
        throw ApiException('Failed to update data: ${response.statusCode}', response.statusCode);
      }
    } on SocketException {
      print('🔌 Network Error: No internet connection');
      throw ApiException('No internet connection', 0);
    } on TimeoutException {
      print('⏱️ Request Timeout');
      throw ApiException('Request timeout', 408);
    } on FormatException {
      print('🔄 Invalid Response Format');
      throw ApiException('Invalid response format', 0);
    } catch (e) {
      print('💥 Unexpected Error: $e');
      throw ApiException('Unexpected error: $e', 0);
    }
  }

  Future<dynamic> delete(String endpoint, {bool requiresAuth = true}) async {
    try {
      final uri = Uri.parse('$baseUrl$endpoint');
      print('🌐 DELETE Request: $uri');
      
      final headers = await _getHeaders(requiresAuth: requiresAuth);
      final response = await httpClient.delete(
        uri,
        headers: headers,
      ).timeout(const Duration(seconds: 60));

      print('📥 Response Status: ${response.statusCode}');
      
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return true;
      } else {
        print('❌ Error Response: ${response.body}');
        throw ApiException('Failed to delete data: ${response.statusCode}', response.statusCode);
      }
    } on SocketException {
      print('🔌 Network Error: No internet connection');
      throw ApiException('No internet connection', 0);
    } on TimeoutException {
      print('⏱️ Request Timeout');
      throw ApiException('Request timeout', 408);
    } on FormatException {
      print('🔄 Invalid Response Format');
      throw ApiException('Invalid response format', 0);
    } catch (e) {
      print('💥 Unexpected Error: $e');
      throw ApiException('Unexpected error: $e', 0);
    }
  }
}

// Custom exception class for API errors
class ApiException implements Exception {
  final String message;
  final int statusCode;

  ApiException(this.message, this.statusCode);

  @override
  String toString() => 'ApiException: $message (Status Code: $statusCode)';
}
