import 'dart:convert';
import 'dart:ui';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/errors/exceptions.dart';
import '../../../../core/network/api_client.dart';
import '../../domain/entities/food_item.dart';
import '../../domain/entities/nutrition_data.dart';
import '../models/food_item_model.dart';
import '../models/nutrition_data_model.dart';
import '../models/daily_food_model.dart';

abstract class FoodRemoteDataSource {
  Future<Map<String, List<FoodItem>>> getDailyFoodData(String date);
  Future<String> getFoodScore();
  Future<String> getDailyFoodScore(String date);
  Future<List<FoodItem>> getPopularFoods();
  Future<NutritionData> getNutritionData(DateTime date);
  Future<bool> addFoodItem(FoodItem foodItem);
  Future<void> updateFoodItem(FoodItem foodItem);
  Future<void> deleteFoodItem(String id);
  Future<bool> logFoodItems(String date, List<Map<String, dynamic>> foodItems);
  Future<List<FoodItem>> getFoodItems(String accessToken);
  Future<Map<String, dynamic>> getMonthlyFoodData(int year, int month);
}

class FoodRemoteDataSourceImpl implements FoodRemoteDataSource {
  final ApiClient apiClient;
  final http.Client client;

  FoodRemoteDataSourceImpl({
    required this.apiClient,
    required this.client,
  });

  @override
  Future<Map<String, List<FoodItem>>> getDailyFoodData(String date) async {
    try {
      print('🍽️ Fetching daily food data for date: $date');
      final response = await apiClient.get('/food/daily/$date');
      
      if (response['success'] == true) {
        print('✅ Successfully fetched daily food data');
        final data = response['data'];
        
        // Process the meals data from the response
        Map<String, List<FoodItem>> result = {
          'breakfast': [],
          'lunch': [],
          'dinner': [],
          'snacks': [],
          'custom': [],
        };
        
        if (data != null && data.containsKey('meals')) {
          final meals = data['meals'] as Map<String, dynamic>;
          
          meals.forEach((mealType, foodList) {
            if (result.containsKey(mealType)) {
              for (var foodItem in foodList) {
                // Parse the time
                DateTime foodTime = DateTime.parse(foodItem['time']);
                
                // Create a standardized food item
                FoodItem processedFood = FoodItemModel(
                  id: foodItem['id'] ?? '',
                  name: foodItem['foodName'],
                  calories: foodItem['calories'] is int
                      ? foodItem['calories']
                      : (foodItem['calories'] as num).toInt(),
                  protein: foodItem['protein'] ?? 0,
                  carbs: foodItem['carbs'] ?? 0,
                  fat: foodItem['fat'] ?? 0,
                  time: _formatTime(foodTime),
                  weight: foodItem['weight'] ?? '100g',
                  mealType: mealType,
                  date: date,
                  color: _getColorForMealType(mealType),
                );
                
                result[mealType]!.add(processedFood);
              }
            }
          });
        }
        
        return result;
      } else {
        print('❌ Failed to fetch daily food data: ${response['message']}');
        throw ServerException(
          message: response['message'] ?? 'Failed to fetch food data',
          statusCode: 500,
        );
      }
    } catch (e) {
      print('❌ Error in getDailyFoodData: $e');
      throw ServerException(message: 'Failed to fetch daily food data: $e', statusCode: 500);
    }
  }

  @override
  Future<Map<String, dynamic>> getMonthlyFoodData(int year, int month) async {
    try {
      print('🗓️ Fetching monthly food data for $month/$year');
      final response = await apiClient.get('/food/monthly/$year/$month');
      
      if (response['success'] == true) {
        print('✅ Successfully fetched monthly food data');
        return response['data'];
      } else {
        print('❌ Failed to fetch monthly food data: ${response['message']}');
        throw ServerException(
          message: response['message'] ?? 'Failed to fetch monthly food data',
          statusCode: 500,
        );
      }
    } catch (e) {
      print('❌ Error in getMonthlyFoodData: $e');
      throw ServerException(message: 'Failed to fetch monthly food data: $e', statusCode: 500);
    }
  }

  @override
  Future<String> getFoodScore() async {
    try {
      final response = await apiClient.get('/food/score/today');
      
      if (response['success'] == true) {
        final score = response['data']['score'].toString();
        return score;
      } else {
        throw ServerException(
          message: response['message'] ?? 'Failed to fetch food score',
          statusCode: 500,
        );
      }
    } catch (e) {
      throw ServerException(message: 'Failed to fetch food score: $e', statusCode: 500);
    }
  }

  @override
  Future<String> getDailyFoodScore(String date) async {
    try {
      // Use the correct API endpoint with the /api prefix
      final client = http.Client();
      final response = await client.get(
        Uri.parse('https://test-prod-f427.onrender.com/api/food/score/daily/$date'),
        headers: {'Content-Type': 'application/json'},
      );
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true && data['data'] != null) {
          final score = data['data']['food_score'].toString();
          return score;
        } else {
          throw ServerException(
            message: data['message'] ?? 'Failed to fetch daily food score',
            statusCode: 500,
          );
        }
      } else {
        throw ServerException(
          message: 'Server error: ${response.statusCode}',
          statusCode: response.statusCode,
        );
      }
    } catch (e) {
      throw ServerException(message: 'Failed to fetch daily food score: $e', statusCode: 500);
    }
  }

  @override
  Future<List<FoodItem>> getPopularFoods() async {
    try {
    // Use direct HTTP request to the correct endpoint
      final response = await client.get(
        Uri.parse('https://food-service-prod.onrender.com/api/food/items'),
        headers: {'Content-Type': 'application/json'},
      );
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true && data['data'] != null) {
          final List<dynamic> foods = data['data'];
          return foods.map((food) => FoodItemModel.fromJson(food)).toList();
        } else {
          throw ServerException(
            message: data['message'] ?? 'Failed to fetch popular foods',
            statusCode: 500,
          );
        }
      } else {
        throw ServerException(
          message: 'Server error: ${response.statusCode}',
          statusCode: response.statusCode,
        );
      }
    } catch (e) {
      print('Error fetching popular foods: $e');
      throw ServerException(message: 'Failed to fetch popular foods: $e', statusCode: 500);
    }
  }

  @override
  Future<NutritionData> getNutritionData(DateTime date) async {
    try {
      final formattedDate = DateFormat('yyyy-MM-dd').format(date);
      final response = await apiClient.get('/food/nutrition/$formattedDate');
      
      if (response['success'] == true) {
        return NutritionDataModel.fromJson(response['data']);
      } else {
        throw ServerException(
          message: response['message'] ?? 'Failed to fetch nutrition data',
          statusCode: 500,
        );
      }
    } catch (e) {
      throw ServerException(message: 'Failed to fetch nutrition data: $e', statusCode: 500);
    }
  }

  @override
  Future<bool> addFoodItem(FoodItem foodItem) async {
    try {
      final response = await apiClient.post(
        '/food/add',
        body: {
          'mealType': foodItem.mealType,
          'foodName': foodItem.name,
          'calories': foodItem.calories,
          'protein': foodItem.protein,
          'carbs': foodItem.carbs,
          'fat': foodItem.fat,
          'weight': foodItem.weight,
          'time': DateTime.now().toIso8601String(),
        },
      );
      
      return response['success'] == true;
    } catch (e) {
      throw ServerException(message: 'Failed to add food item: $e', statusCode: 500);
    }
  }

  @override
  Future<void> updateFoodItem(FoodItem foodItem) async {
    try {
      await apiClient.put(
        '/food/${foodItem.id}',
        body: {
          'mealType': foodItem.mealType,
          'foodName': foodItem.name,
          'calories': foodItem.calories,
          'protein': foodItem.protein,
          'carbs': foodItem.carbs,
          'fat': foodItem.fat,
          'weight': foodItem.weight,
        },
      );
    } catch (e) {
      throw ServerException(message: 'Failed to update food item: $e', statusCode: 500);
    }
  }

  @override
  Future<void> deleteFoodItem(String id) async {
    try {
      await apiClient.delete('/food/$id');
    } catch (e) {
      throw ServerException(message: 'Failed to delete food item: $e', statusCode: 500);
    }
  }

  @override
  Future<bool> logFoodItems(String date, List<Map<String, dynamic>> foodItems) async {
    try {
      final response = await apiClient.post(
        '/food/log',
        body: {
          'date': date,
          'foodItems': foodItems,
        },
      );
      
      return response['success'] == true;
    } catch (e) {
      throw ServerException(message: 'Failed to log food items: $e', statusCode: 500);
    }
  }

  @override
  Future<List<FoodItem>> getFoodItems(String accessToken) async {
    try {
      final response = await apiClient.get('/food/items');
      
      if (response['success'] == true) {
        final List<dynamic> items = response['data'];
        return items.map((item) => FoodItemModel.fromJson(item)).toList();
      } else {
        throw ServerException(
          message: response['message'] ?? 'Failed to fetch food items',
          statusCode: 500,
        );
      }
    } catch (e) {
      throw ServerException(message: 'Failed to fetch food items: $e', statusCode: 500);
    }
  }

  // Helper method to format time
  String _formatTime(DateTime dateTime) {
    int hour = dateTime.hour;
    String period = hour >= 12 ? 'PM' : 'AM';

    if (hour > 12) hour -= 12;
    if (hour == 0) hour = 12;

    String minute = dateTime.minute.toString().padLeft(2, '0');

    return '$hour:$minute $period';
  }

  // Helper method to get color for meal type
  Color _getColorForMealType(String mealType) {
    switch (mealType) {
      case 'breakfast':
        return const Color(0xFFFF9500);
      case 'lunch':
        return const Color(0xFF0A84FF);
      case 'dinner':
        return const Color(0xFF5E5CE6);
      case 'snacks':
        return const Color(0xFF66BB6A);
      default:
        return const Color(0xFF9E9E9E);
    }
  }

  // Helper method to get icon name for meal type
  String _getIconNameForMealType(String mealType) {
    switch (mealType) {
      case 'breakfast':
        return 'breakfast_dining';
      case 'lunch':
        return 'lunch_dining';
      case 'dinner':
        return 'dinner_dining';
      case 'snacks':
        return 'food_bank';
      default:
        return 'local_dining';
    }
  }
}
